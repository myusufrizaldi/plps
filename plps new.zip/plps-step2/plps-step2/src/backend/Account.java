package backend;

public interface Account {
    public abstract void updatePassword (String passwordLama, String passwordBaru);
}
